import streamlit as st
import importlib, time
try:
    import fiboevo as fibo
except Exception:
    fibo = importlib.import_module("fiboevo")

from utils import fetch_ccxt_ohlcv
import ccxt

def render():
    st.header("Trading Live (Testnet/Mainnet)")
    mode = st.selectbox("Mode", ["Paper/Testnet (sandbox)", "Mainnet"])
    exchange_id = st.text_input("Exchange id", value="binance")
    symbol = st.text_input("Symbol", value="BTC/USDT")
    timeframe = st.selectbox("Timeframe", ["1m","5m","15m","30m","1h","4h","1d"], index=4)
    api_key = st.text_input("API Key", value="", type="password")
    api_secret = st.text_input("API Secret", value="", type="password")

    st.markdown("**Note**: this UI issues direct CCXT calls. Be careful when using Mainnet. Use Testnet / sandbox when possible.")

    if st.button("Fetch latest OHLCV via CCXT"):
        try:
            df = fetch_ccxt_ohlcv(symbol=symbol, timeframe=timeframe, limit=500, exchange_id=exchange_id, api_key=api_key, api_secret=api_secret, sandbox=(mode.startswith("Paper")))
            st.session_state["fetched_df"] = df
            st.success("Fetched latest OHLCV and stored in session")
        except Exception as e:
            st.error(f"Fetch failed: {e}")

    st.markdown("---")
    st.subheader("Manual Order (ccxt)")
    side = st.selectbox("Side", ["buy","sell"])
    order_type = st.selectbox("Type", ["limit","market"])
    amount = st.number_input("Amount (units)", value=0.001)
    price = st.number_input("Price (for limit)", value=0.0)
    if st.button("Place order via CCXT"):
        try:
            exchange_cls = getattr(ccxt, exchange_id)
            exchange = exchange_cls({"apiKey": api_key, "secret": api_secret, "enableRateLimit": True})
            if mode.startswith("Paper"):
                try:
                    exchange.set_sandbox_mode(True)
                except Exception:
                    pass
            params = {}
            if order_type == "market":
                order = exchange.create_market_order(symbol, side, amount, params=params)
            else:
                order = exchange.create_limit_order(symbol, side, amount, price, params=params)
            st.write("Order response:")
            st.json(order)
        except Exception as e:
            st.error(f"Order failed: {e}")

# --- added: ledger metrics and automation helpers ---
def compute_ledger_metrics(ledger_df: pd.DataFrame):
    if ledger_df is None or len(ledger_df)==0:
        return pd.DataFrame(), None
    df = ledger_df.copy()
    for c in ['executed_price','amount']:
        if c not in df.columns:
            df[c] = 0.0
    df['notional'] = df['executed_price'].fillna(0.0) * df['amount'].fillna(0.0)
    df['signed'] = df.apply(lambda r: r['notional'] if str(r.get('side')).lower()=='sell' else -r['notional'], axis=1)
    df['cum_cash'] = df['signed'].cumsum()
    start_cap = 10000.0
    df['equity'] = start_cap + (-df['cum_cash'])
    return df, df[['equity']]

# Add dashboard display at bottom if ledger exists
def show_trading_dashboard():
    ledger = read_ledger()
    if ledger is None or len(ledger)==0:
        st.info('No trades recorded yet - ledger empty.')
        return
    df, eq = compute_ledger_metrics(ledger)
    st.subheader('Trading dashboard (simple)')
    st.write('Total trades:', len(df))
    pnl = -df['cum_cash'].iloc[-1] if len(df)>0 else 0.0
    st.metric('PnL (approx)', f'{pnl:.2f} USD')
    st.line_chart(eq['equity'])

